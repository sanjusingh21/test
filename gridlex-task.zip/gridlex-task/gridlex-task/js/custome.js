$(document).ready(function () {

    // counter 
    $('.counter').counterUp({
      time: 1000
    });

    // banner slider
    $('.carousel').carousel({
      interval: 3500
    })

    // boostrap accordian
    $("#accord").click(() => {
      if ($("#collapseExample").hasClass("show")) {
        $("#accpic").attr("src", "images/accdown.png");
      } else
        $("#accpic").attr("src", "images/accup.png");
    });

    // fixed Header
    /*  check on scoll   */
    $(window).on("scroll",()=>{
     let headerHeight = $("header").outerHeight();
     if($(this).scrollTop()> headerHeight){
        $("header").addClass("scrolled");
     }else{
      $("header").removeClass("scrolled");
     }


    //  for contact form collapse
    var hT = $('#contactus').offset().top,
        hH = $('#contactus').outerHeight(),
        wH = $(window).height(),
        wS = $(this).scrollTop();
    if (wS > (hT+hH-wH)){
      $("#collapseExample").collapse('show')
    }

    });
    /* checking when document got load */
    if($(this).scrollTop()> $("header").outerHeight()){
      $("header").addClass("scrolled");
    }

    //  for contact form collapse
    $(window).bind('mousewheel', function(event) {
        if (event.originalEvent.wheelDelta >= 0) {
          $("#collapseExample").collapse('hide')
        }
    });

    // contact form 
    $("#contactForm").on("submit",(e)=>{
      e.preventDefault();
      const formData = new FormData($("#contactForm")[0])
      if(formData.get('email').trim() == '' || formData.get('phone').trim() == '' || formData.get('message').trim() == ''){
        alert("Please fill all fields");
        return false;
      }
      $("#formModalBody").append(`
          <p><b>Email Address :</b> ${formData.get('email')}</p>
          <p><b>Phone Number :</b> ${formData.get('phone')}</p>
          <p><b>Message :</b> ${formData.get('message')}</p>
      `);
      $('#exampleModal').modal("show");
    })

    // for scorll spy
    $('body').scrollspy({ target: '#navbar' });
    
  });



  


  